import type { Express } from "express";
import { type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.animes.list.path, async (req, res) => {
    const animes = await storage.getAnimes();
    res.json(animes);
  });

  app.get(api.animes.get.path, async (req, res) => {
    const anime = await storage.getAnime(Number(req.params.id));
    if (!anime) {
      return res.status(404).json({ message: 'Anime not found' });
    }
    res.json(anime);
  });

  app.get(api.animes.recommendations.path, async (req, res) => {
    const animes = await storage.getRecommendations(Number(req.params.id));
    if (!animes) {
      return res.status(404).json({ message: 'Anime not found' });
    }
    res.json(animes);
  });

  app.get(api.watchlist.list.path, async (req, res) => {
    const list = await storage.getWatchlist();
    res.json(list);
  });

  app.post(api.watchlist.add.path, async (req, res) => {
    const animeId = Number(req.params.animeId);
    await storage.addToWatchlist(animeId);
    res.json({ success: true });
  });

  app.delete(api.watchlist.remove.path, async (req, res) => {
    const animeId = Number(req.params.animeId);
    await storage.removeFromWatchlist(animeId);
    res.json({ success: true });
  });

  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingAnimes = await storage.getAnimes();
  if (existingAnimes.length === 0) {
    try {
      const response = await fetch('https://api.jikan.moe/v4/top/anime?filter=bypopularity&limit=10');
      const json = await response.json();
      const topAnime = json.data;

      for (const anime of topAnime) {
        await storage.createAnime({
          malId: anime.mal_id,
          title: anime.title,
          description: anime.synopsis || "No description available.",
          imageUrl: anime.images?.webp?.large_image_url || anime.images?.jpg?.large_image_url || "",
          coverUrl: anime.images?.webp?.large_image_url || anime.images?.jpg?.large_image_url || "",
          genre: anime.genres?.[0]?.name || "Action",
          score: anime.score?.toString() || "N/A",
          status: anime.status || "Unknown",
          episodes: anime.episodes || 0,
          year: anime.year || 0,
        });
      }
    } catch (error) {
      console.error("Failed to seed from Jikan API:", error);
    }
  }
}

import { db } from "./db";
import { animes, watchlist, type InsertAnime, type Anime } from "@shared/schema";
import { eq, inArray } from "drizzle-orm";

export interface IStorage {
  getAnimes(): Promise<Anime[]>;
  getAnime(id: number): Promise<Anime | undefined>;
  getAnimeByMalId(malId: number): Promise<Anime | undefined>;
  getRecommendations(id: number): Promise<Anime[]>;
  createAnime(anime: InsertAnime): Promise<Anime>;
  
  getWatchlist(): Promise<Anime[]>;
  addToWatchlist(animeId: number): Promise<void>;
  removeFromWatchlist(animeId: number): Promise<void>;
  isInWatchlist(animeId: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getAnimes(): Promise<Anime[]> {
    return await db.select().from(animes);
  }

  async getAnime(id: number): Promise<Anime | undefined> {
    const [anime] = await db.select().from(animes).where(eq(animes.id, id));
    return anime;
  }

  async getAnimeByMalId(malId: number): Promise<Anime | undefined> {
    const [anime] = await db.select().from(animes).where(eq(animes.malId, malId));
    return anime;
  }

  async getRecommendations(id: number): Promise<Anime[]> {
    const [anime] = await db.select().from(animes).where(eq(animes.id, id));
    if (!anime) return [];
    
    const recommended = await db.select().from(animes).where(eq(animes.genre, anime.genre));
    return recommended.filter(a => a.id !== id).slice(0, 5);
  }

  async createAnime(anime: InsertAnime): Promise<Anime> {
    const [created] = await db.insert(animes).values(anime).returning();
    return created;
  }

  async getWatchlist(): Promise<Anime[]> {
    const items = await db.select().from(watchlist);
    if (items.length === 0) return [];
    const ids = items.map(i => i.animeId);
    return await db.select().from(animes).where(inArray(animes.id, ids));
  }

  async addToWatchlist(animeId: number): Promise<void> {
    const exists = await this.isInWatchlist(animeId);
    if (!exists) {
      await db.insert(watchlist).values({ animeId });
    }
  }

  async removeFromWatchlist(animeId: number): Promise<void> {
    await db.delete(watchlist).where(eq(watchlist.animeId, animeId));
  }

  async isInWatchlist(animeId: number): Promise<boolean> {
    const [item] = await db.select().from(watchlist).where(eq(watchlist.animeId, animeId));
    return !!item;
  }
}

export const storage = new DatabaseStorage();

## Packages
framer-motion | Required for smooth vertical parallax scrolling, entry animations, and page transitions.
lucide-react | Beautiful, consistent icons for UI elements (back buttons, play/info icons).
clsx | Utility for constructing `className` strings conditionally.
tailwind-merge | Utility to efficiently merge Tailwind CSS classes without style conflicts.

## Notes
- Relies on `@shared/routes` exporting the `api` manifest and `buildUrl` helper for robust API typing.
- Images rely on `imageUrl` and `coverUrl` fields from the backend database (assumed to be seeded with valid image URLs).
- Parallax effect uses window scroll events; works best on modern browsers.

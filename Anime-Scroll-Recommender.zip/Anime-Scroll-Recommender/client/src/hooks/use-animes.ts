import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

export function useAnimes() {
  return useQuery({
    queryKey: [api.animes.list.path],
    queryFn: async () => {
      const res = await fetch(api.animes.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch animes");
      const data = await res.json();
      return api.animes.list.responses[200].parse(data);
    },
  });
}

export function useAnime(id: number | string) {
  const numericId = typeof id === 'string' ? parseInt(id, 10) : id;
  const path = buildUrl(api.animes.get.path, { id: numericId });
  
  return useQuery({
    queryKey: [api.animes.get.path, numericId],
    queryFn: async () => {
      const res = await fetch(path, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch anime details");
      const data = await res.json();
      return api.animes.get.responses[200].parse(data);
    },
    enabled: !isNaN(numericId),
  });
}

export function useAnimeRecommendations(id: number | string) {
  const numericId = typeof id === 'string' ? parseInt(id, 10) : id;
  const path = buildUrl(api.animes.recommendations.path, { id: numericId });

  return useQuery({
    queryKey: [api.animes.recommendations.path, numericId],
    queryFn: async () => {
      const res = await fetch(path, { credentials: "include" });
      if (res.status === 404) return [];
      if (!res.ok) throw new Error("Failed to fetch recommendations");
      const data = await res.json();
      return api.animes.recommendations.responses[200].parse(data);
    },
    enabled: !isNaN(numericId),
  });
}

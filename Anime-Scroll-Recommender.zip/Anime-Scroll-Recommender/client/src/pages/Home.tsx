import { useAnimes } from "@/hooks/use-animes";
import { ParallaxHero } from "@/components/ParallaxHero";
import { PageTransition } from "@/components/PageTransition";
import { motion } from "framer-motion";

export default function Home() {
  const { data: animes, isLoading, error } = useAnimes();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center">
        <div className="relative w-24 h-24">
          <div className="absolute inset-0 border-4 border-primary/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin"></div>
        </div>
        <h2 className="mt-8 text-2xl font-bold tracking-widest uppercase text-white/50 animate-pulse">Loading Realm</h2>
      </div>
    );
  }

  if (error || !animes) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center">
        <div className="text-destructive mb-4">
          <svg className="w-16 h-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h1 className="text-3xl font-bold mb-2">Connection Lost</h1>
        <p className="text-muted-foreground max-w-md">Could not establish a link to the anime database. Please check your connection and try again.</p>
      </div>
    );
  }

  if (animes.length === 0) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center relative overflow-hidden">
        {/* Placeholder background if db is empty */}
        {/* landing page hero scenic mountain landscape anime style placeholder */}
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <img src="https://images.unsplash.com/photo-1541701494587-cb58502866ab?q=80&w=2070&auto=format&fit=crop" alt="Empty world" className="w-full h-full object-cover mix-blend-luminosity" />
        </div>
        <div className="relative z-10 glass-panel p-12 rounded-3xl max-w-lg">
          <h1 className="text-4xl font-display font-bold mb-4 text-glow">The Void is Empty</h1>
          <p className="text-white/70 mb-8">No anime series have been discovered yet. The database awaits its first entry.</p>
        </div>
      </div>
    );
  }

  return (
    <PageTransition className="bg-background snap-y snap-mandatory h-[100svh] overflow-y-auto overflow-x-hidden">
      {animes.map((anime, index) => (
        <ParallaxHero 
          key={anime.id} 
          anime={anime} 
          isFirst={index === 0} 
        />
      ))}
    </PageTransition>
  );
}

import { useAnimes } from "@/hooks/use-animes";
import { PageTransition } from "@/components/PageTransition";
import { AnimeCard } from "@/components/AnimeCard";
import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export default function Watchlist() {
  const { data: watchlist, isLoading } = useQuery({
    queryKey: [api.watchlist.list.path],
    queryFn: async () => {
      const res = await fetch(api.watchlist.list.path);
      if (!res.ok) throw new Error("Failed to fetch watchlist");
      return res.json();
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <PageTransition className="min-h-screen bg-background pt-32 pb-24">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl font-black mb-12 text-glow">My Watchlist</h1>
        
        {!watchlist || watchlist.length === 0 ? (
          <div className="glass-panel p-12 rounded-3xl text-center">
            <p className="text-xl text-white/50">Your watchlist is empty. Go find some anime to watch!</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
            {watchlist.map((anime: any, i: number) => (
              <AnimeCard key={anime.id} anime={anime} index={i} />
            ))}
          </div>
        )}
      </div>
    </PageTransition>
  );
}

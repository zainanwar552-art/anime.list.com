import { useParams, Link, useLocation } from "wouter";
import { useAnime, useAnimeRecommendations } from "@/hooks/use-animes";
import { PageTransition } from "@/components/PageTransition";
import { AnimeCard } from "@/components/AnimeCard";
import { motion } from "framer-motion";
import { ArrowLeft, PlayCircle, Star, Calendar, Clock, BookmarkPlus, Check } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import type { Anime } from "@shared/schema";

function WatchlistButton({ animeId }: { animeId: number }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: watchlist } = useQuery<Anime[]>({ queryKey: [api.watchlist.list.path] });
  const isInWatchlist = watchlist?.some(item => item.id === animeId);

  const addMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(buildUrl(api.watchlist.add.path, { animeId }), { method: 'POST' });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.watchlist.list.path] });
      toast({ title: "Added to Watchlist" });
    }
  });

  const removeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(buildUrl(api.watchlist.remove.path, { animeId }), { method: 'DELETE' });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.watchlist.list.path] });
      toast({ title: "Removed from Watchlist" });
    }
  });

  if (isInWatchlist) {
    return (
      <button 
        onClick={() => removeMutation.mutate()}
        className="px-8 py-3 rounded-xl glass-panel text-primary font-bold hover:bg-white/10 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
      >
        <Check className="w-5 h-5" />
        In Watchlist
      </button>
    );
  }

  return (
    <button 
      onClick={() => addMutation.mutate()}
      className="px-8 py-3 rounded-xl glass-panel text-white font-bold hover:bg-white/10 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
    >
      <BookmarkPlus className="w-5 h-5" />
      Add to List
    </button>
  );
}

export default function AnimeDetails() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { data: anime, isLoading, error } = useAnime(id!);
  const { data: recommendations, isLoading: isRecsLoading } = useAnimeRecommendations(id!);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (error || !anime) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center">
        <h1 className="text-4xl font-bold mb-4">Anime Not Found</h1>
        <button onClick={() => setLocation("/")} className="text-primary hover:underline">
          Return to Home
        </button>
      </div>
    );
  }

  return (
    <PageTransition className="min-h-screen bg-background pb-24">
      {/* Hero Header */}
      <div className="relative h-[60vh] md:h-[70vh] w-full overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={anime.imageUrl} 
            alt={anime.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
          <div className="absolute inset-0 bg-black/30" />
        </div>

        {/* Top Nav */}
        <div className="absolute top-0 left-0 right-0 p-6 z-30">
          <Link 
            href="/"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-panel hover:bg-white/10 transition-colors text-white font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Link>
        </div>

        {/* Hero Content */}
        <div className="absolute bottom-0 left-0 right-0 z-20">
          <div className="container mx-auto px-6 pb-12">
            <div className="flex flex-col md:flex-row gap-8 items-end">
              
              {/* Cover Image */}
              <motion.div 
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="w-48 md:w-64 flex-shrink-0 hidden md:block rounded-2xl overflow-hidden shadow-2xl shadow-black/50 border border-white/10 relative -mb-16 z-30"
              >
                <img src={anime.coverUrl} alt="Cover" className="w-full aspect-[3/4] object-cover" />
              </motion.div>

              {/* Title & Meta */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="flex-1"
              >
                <div className="flex flex-wrap gap-3 mb-4">
                  <span className="px-3 py-1 rounded-md bg-primary/20 text-primary text-xs font-bold uppercase tracking-wider border border-primary/30">
                    {anime.genre}
                  </span>
                  <span className="px-3 py-1 rounded-md glass-panel text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <Star className="w-3.5 h-3.5 text-yellow-400" /> 9.8
                  </span>
                </div>
                
                <h1 className="text-4xl md:text-6xl font-black mb-4 text-glow leading-tight">
                  {anime.title}
                </h1>
                
                <div className="flex flex-wrap gap-6 text-sm text-white/60 mb-8 font-medium">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" /> 2024
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" /> 24 Episodes
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500 box-glow" /> Ongoing
                  </div>
                </div>

                <div className="flex gap-4">
                  <button className="px-8 py-3 rounded-xl bg-primary text-white font-bold hover:bg-primary/90 transition-all hover:scale-105 active:scale-95 shadow-lg shadow-primary/25 flex items-center gap-2">
                    <PlayCircle className="w-5 h-5" />
                    Watch Now
                  </button>
                  <WatchlistButton animeId={anime.id} />
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 mt-16 md:mt-24">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Main Content Column */}
          <div className="lg:col-span-2 space-y-12">
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-3">
                <span className="w-1.5 h-6 bg-primary rounded-full" />
                Synopsis
              </h2>
              <p className="text-lg text-white/70 leading-relaxed">
                {anime.description}
              </p>
            </motion.section>
          </div>
        </div>

        {/* Recommendations Section */}
        <motion.section 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="mt-24 pt-12 border-t border-white/5"
        >
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-glow">Similar to {anime.title}</h2>
          </div>
          
          {isRecsLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="aspect-[3/4] rounded-2xl bg-card border border-white/5 animate-pulse" />
              ))}
            </div>
          ) : recommendations && recommendations.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {recommendations.map((rec, i) => (
                <AnimeCard key={rec.id} anime={rec} index={i} />
              ))}
            </div>
          ) : (
             <div className="py-12 text-center glass-panel rounded-2xl">
               <p className="text-muted-foreground">No recommendations available at the moment.</p>
             </div>
          )}
        </motion.section>
      </div>
    </PageTransition>
  );
}

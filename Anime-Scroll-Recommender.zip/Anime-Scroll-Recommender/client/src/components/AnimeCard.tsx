import { Link } from "wouter";
import { motion } from "framer-motion";
import { Play, BookmarkPlus, Check } from "lucide-react";
import type { Anime } from "@shared/schema";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

interface AnimeCardProps {
  anime: Anime;
  index: number;
}

export function AnimeCard({ anime, index }: AnimeCardProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: watchlist } = useQuery<Anime[]>({
    queryKey: [api.watchlist.list.path]
  });

  const isInWatchlist = watchlist?.some(item => item.id === anime.id);

  const addMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(buildUrl(api.watchlist.add.path, { animeId: anime.id }), { method: 'POST' });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.watchlist.list.path] });
      toast({ title: "Added to Watchlist", description: anime.title });
    }
  });

  const removeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(buildUrl(api.watchlist.remove.path, { animeId: anime.id }), { method: 'DELETE' });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.watchlist.list.path] });
      toast({ title: "Removed from Watchlist", description: anime.title });
    }
  });

  const toggleWatchlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isInWatchlist) {
      removeMutation.mutate();
    } else {
      addMutation.mutate();
    }
  };

  return (
    <Link href={`/anime/${anime.id}`} className="block group outline-none">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: index * 0.1, ease: "easeOut" }}
        className="relative overflow-hidden rounded-2xl aspect-[3/4] glossy-card group-hover:shadow-primary/40 transition-all duration-500 cursor-pointer"
      >
        {/* Background Image */}
        <div className="absolute inset-0">
          <img 
            src={anime.coverUrl || anime.imageUrl} 
            alt={anime.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-focus:scale-110"
            loading="lazy"
          />
        </div>
        
        {/* Watchlist Toggle */}
        <button 
          onClick={toggleWatchlist}
          disabled={addMutation.isPending || removeMutation.isPending}
          className="absolute top-4 right-4 z-30 w-10 h-10 rounded-full glass-panel flex items-center justify-center transition-all hover:scale-110 active:scale-95 text-white"
        >
          {isInWatchlist ? <Check className="w-5 h-5 text-primary" /> : <BookmarkPlus className="w-5 h-5" />}
        </button>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300" />
        
        {/* Hover Action Icon */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform scale-75 group-hover:scale-100 group-focus:opacity-100 group-focus:scale-100 z-20">
          <div className="w-16 h-16 rounded-full bg-primary/20 backdrop-blur-md flex items-center justify-center border border-primary/50 text-white">
            <Play className="w-6 h-6 ml-1" fill="currentColor" />
          </div>
        </div>

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-5 z-10 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
          <div className="inline-block px-2.5 py-1 mb-3 rounded-full text-xs font-semibold tracking-wider uppercase bg-primary/20 text-primary border border-primary/30 backdrop-blur-sm">
            {anime.genre}
          </div>
          <h3 className="text-xl font-bold text-white line-clamp-2 leading-tight">
            {anime.title}
          </h3>
        </div>
      </motion.div>
    </Link>
  );
}

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Link } from "wouter";
import { Info } from "lucide-react";
import type { Anime } from "@shared/schema";

interface ParallaxHeroProps {
  anime: Anime;
  isFirst?: boolean;
}

export function ParallaxHero({ anime, isFirst = false }: ParallaxHeroProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  });

  // Cloud parallax background
  const yClouds = useTransform(scrollYProgress, [0, 1], ["0%", "10%"]);
  // Content moves slightly up and fades out
  const yContent = useTransform(scrollYProgress, [0, 0.5], ["0%", "-10%"]);
  const opacityContent = useTransform(scrollYProgress, [0, 0.4, 0.6], [1, 1, 0]);

  return (
    <section 
      ref={containerRef}
      className="relative h-[100svh] w-full overflow-hidden flex items-center justify-center snap-center bg-transparent"
    >
      {/* Parallax Clouds Layer */}
      <motion.div 
        className="absolute inset-0 z-0 pointer-events-none opacity-40"
        style={{ y: yClouds }}
      >
        <img 
          src="https://images.unsplash.com/photo-1513002749550-c59d786b8e6c?q=80&w=2574&auto=format&fit=crop" 
          alt="Clouds"
          className="w-full h-[120%] object-cover"
        />
      </motion.div>
      
      {/* Background Anime Image */}
      <div className="absolute inset-0 z-1" >
        <div className="absolute inset-0 bg-background/40 z-10" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/60 to-background z-10" />
        <img 
          src={anime.imageUrl} 
          alt={anime.title}
          className="w-full h-full object-cover object-center"
        />
      </div>

      {/* Foreground Content */}
      <motion.div 
        className="relative z-20 container mx-auto px-6 lg:px-12 flex flex-col items-center text-center max-w-5xl"
        style={{ y: yContent, opacity: opacityContent }}
        initial={isFirst ? { opacity: 0, y: 30 } : false}
        animate={isFirst ? { opacity: 1, y: 0 } : false}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <motion.span 
          initial={isFirst ? { opacity: 0, scale: 0.9 } : false}
          animate={isFirst ? { opacity: 1, scale: 1 } : false}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="px-4 py-1.5 rounded-full bg-primary/20 text-primary border border-primary/30 backdrop-blur-md text-sm font-bold tracking-[0.2em] uppercase mb-6"
        >
          {anime.genre}
        </motion.span>
        
        <motion.h1 
          initial={isFirst ? { opacity: 0, y: 20 } : false}
          animate={isFirst ? { opacity: 1, y: 0 } : false}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-5xl md:text-7xl lg:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-white/60 mb-6 text-glow drop-shadow-2xl"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          {anime.title}
        </motion.h1>
        
        <motion.p 
          initial={isFirst ? { opacity: 0 } : false}
          animate={isFirst ? { opacity: 1 } : false}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="text-lg md:text-xl text-white/80 max-w-2xl mb-10 line-clamp-3 leading-relaxed"
        >
          {anime.description}
        </motion.p>

        <motion.div
          initial={isFirst ? { opacity: 0, y: 20 } : false}
          animate={isFirst ? { opacity: 1, y: 0 } : false}
          transition={{ duration: 0.6, delay: 0.9 }}
        >
          <Link 
            href={`/anime/${anime.id}`}
            className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-white text-black font-bold text-lg overflow-hidden hover:scale-105 active:scale-95 transition-transform duration-300"
          >
            <span className="relative z-10 flex items-center gap-2">
              <Info className="w-5 h-5" />
              Discover Series
            </span>
            <div className="absolute inset-0 bg-primary translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-in-out" />
            <span className="absolute z-10 flex items-center gap-2 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <Info className="w-5 h-5" />
              Discover Series
            </span>
          </Link>
        </motion.div>
      </motion.div>

      {/* Scroll indicator for the first item */}
      {isFirst && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-20 opacity-50"
        >
          <span className="text-xs tracking-widest uppercase font-medium">Scroll</span>
          <div className="w-[1px] h-12 bg-white/20 relative overflow-hidden">
            <motion.div 
              animate={{ y: ["-100%", "100%"] }}
              transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
              className="absolute inset-0 bg-primary"
            />
          </div>
        </motion.div>
      )}
    </section>
  );
}

import { Link, useLocation } from "wouter";
import { Bookmark, Home as HomeIcon } from "lucide-react";
import { motion } from "framer-motion";

export function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 p-6 flex justify-center">
      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="glass-panel px-6 py-3 rounded-full flex items-center gap-8 shadow-2xl"
      >
        <Link href="/" className={`flex items-center gap-2 font-bold transition-colors ${location === '/' ? 'text-primary' : 'text-white/70 hover:text-white'}`}>
          <HomeIcon className="w-4 h-4" />
          Home
        </Link>
        <Link href="/watchlist" className={`flex items-center gap-2 font-bold transition-colors ${location === '/watchlist' ? 'text-primary' : 'text-white/70 hover:text-white'}`}>
          <Bookmark className="w-4 h-4" />
          My Watchlist
        </Link>
      </motion.div>
    </nav>
  );
}

import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const animes = pgTable("animes", {
  id: serial("id").primaryKey(),
  malId: integer("mal_id").unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  coverUrl: text("cover_url").notNull(),
  genre: text("genre").notNull(),
  score: text("score"),
  status: text("status"),
  episodes: integer("episodes"),
  year: integer("year"),
});

export const watchlist = pgTable("watchlist", {
  id: serial("id").primaryKey(),
  animeId: integer("anime_id").notNull().references(() => animes.id),
});

export const insertAnimeSchema = createInsertSchema(animes).omit({ id: true });
export const insertWatchlistSchema = createInsertSchema(watchlist).omit({ id: true });

export type Anime = typeof animes.$inferSelect;
export type InsertAnime = z.infer<typeof insertAnimeSchema>;
export type WatchlistItem = typeof watchlist.$inferSelect;
export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;

import { z } from 'zod';
import { animes, watchlist } from './schema';

export const errorSchemas = {
  notFound: z.object({ message: z.string() }),
};

export const api = {
  animes: {
    list: {
      method: 'GET' as const,
      path: '/api/animes' as const,
      responses: {
        200: z.array(z.custom<typeof animes.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/animes/:id' as const,
      responses: {
        200: z.custom<typeof animes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    recommendations: {
      method: 'GET' as const,
      path: '/api/animes/:id/recommendations' as const,
      responses: {
        200: z.array(z.custom<typeof animes.$inferSelect>()),
        404: errorSchemas.notFound,
      },
    }
  },
  watchlist: {
    list: {
      method: 'GET' as const,
      path: '/api/watchlist' as const,
      responses: {
        200: z.array(z.custom<typeof animes.$inferSelect>()),
      },
    },
    add: {
      method: 'POST' as const,
      path: '/api/watchlist/:animeId' as const,
      responses: {
        200: z.object({ success: z.boolean() }),
        404: errorSchemas.notFound,
      },
    },
    remove: {
      method: 'DELETE' as const,
      path: '/api/watchlist/:animeId' as const,
      responses: {
        200: z.object({ success: z.boolean() }),
        404: errorSchemas.notFound,
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
